
<?php $__env->startSection('content'); ?>
<section class="dashboard">
    <div class="top">
        <i class="uil uil-bars sidebar-toggle"></i>

        <div class="search-box">
            <i class="uil uil-search"></i>
            <input type="text" placeholder="Search here...">
        </div>

        <img src="/images/profil.png" alt="">
    </div>
    <div class="dash-content">
        <div class="activity">
            <div class="title">
                <i class="uil uil-clipboard-notes"></i>
                <span class="text">Hasil Prediksi Penjualan (Juli - Desember)</span>
            </div>

            <table id="datatable" class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jul</th>
                        <th>Agu</th>
                        <th>Sep</th>
                        <th>Okt</th>
                        <th>Nov</th>
                        <th>Des</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr onclick="window.location='<?php echo e(url('/admin/detail-produk/' . $item->produk->id)); ?>'" style="cursor: pointer;">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->produk->nama_produk); ?></td>
                            <td><?php echo e(number_format($item->produk->harga_satuan)); ?></td>
                            <td><?php echo e($item->jul); ?></td>
                            <td><?php echo e($item->agu); ?></td>
                            <td><?php echo e($item->sep); ?></td>
                            <td><?php echo e($item->okt); ?></td>
                            <td><?php echo e($item->nov); ?></td>
                            <td><?php echo e($item->des); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="9" class="text-center">Belum ada data prediksi.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script> $(function () { $('#datatable').DataTable(); }); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\prediksi-sembako\resources\views/admin/hasil-prediksi.blade.php ENDPATH**/ ?>
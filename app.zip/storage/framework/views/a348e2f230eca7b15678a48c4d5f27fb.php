<?php $__env->startSection('content'); ?>
    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>

            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>

            <img src="/images/profil.png" alt="">
        </div>

        <div class="dash-content">
            <div class="activity">
                <div class="title">
                    <i class="uil uil-book-open"></i>
                    <span class="text">Data Materi</span>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="row mb-3">
                    <div class="col-lg-2 ">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            <i class="uil uil-plus"></i> Tambah Materi
                        </button>
                    </div>
                    <div class="col-lg-2 ">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambahKategori">
                            <i class="uil uil-folder-plus"></i> Tambah Kategori
                        </button>
                    </div>
                </div>


                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm h-100 d-flex flex-column">
                                <?php if($item->gambar): ?>
                                    <img src="<?php echo e(asset($item->gambar)); ?>" class="card-img-top img-fluid" alt="gambar materi"
                                        style="height: 300px; object-fit: cover; width: 100%; min-width: 100%;">
                                <?php endif; ?>

                                <div class="card-body d-flex flex-column">
                                    
                                    <div class="flex-grow-1">
                                        <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                                        <p class="card-text mb-1">
                                            <strong>Kategori:</strong> <?php echo e($item->kategori->nama ?? '-'); ?>

                                        </p>
                                        <p class="card-text mb-1">
                                            <?php echo e(\Illuminate\Support\Str::words(strip_tags($item->isi), 10, '...')); ?>

                                        </p>
                                        <p class="card-text">
                                            <strong>Video:</strong>
                                            <?php if($item->link_video): ?>
                                                <a href="<?php echo e($item->link_video); ?>" target="_blank">Lihat Video</a>
                                            <?php else: ?>
                                                <span class="text-muted">Tidak ada</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>

                                    
                                    <div class="row mt-3">
                                        <div class="col-6 pe-1">
                                            <button class="btn btn-primary w-100" data-bs-toggle="modal"
                                                data-bs-target="#modalEdit<?php echo e($item->id); ?>">
                                                <i class="uil uil-edit"></i> Edit
                                            </button>
                                        </div>
                                        <div class="col-6 ps-1">
                                            <form action="<?php echo e(route('materi.destroy', $item->id)); ?>" method="POST"
                                                onsubmit="return confirm('Yakin hapus materi ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger w-100">
                                                    <i class="uil uil-trash-alt"></i> Hapus
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <p class="text-muted">Belum ada data materi.</p>
                        </div>
                    <?php endif; ?>
                </div>



            </div>
        </div>
    </section>

    <!-- Modal Tambah Kategori -->
    <div class="modal fade" id="modalTambahKategori" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('kategori.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Kategori</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label>Nama Kategori</label>
                            <input type="text" name="nama" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary">Simpan</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Tambah -->
    <div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <form action="<?php echo e(route('materi.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Materi</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Judul</label>
                                <input type="text" name="judul" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Kategori</label>
                                <select name="kategori_id" class="form-control">
                                    <option value="">-- Pilih Kategori --</option>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Link Video</label>
                                <input type="url" name="link_video" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Gambar Cover</label>
                                <input type="file" name="gambar" class="form-control">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label>Isi Materi</label>
                            <textarea name="isi" id="editorIsi"></textarea>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary">Simpan</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <!-- Modal Edit -->
    <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modalEdit<?php echo e($item->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(route('materi.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Materi</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>Judul</label>
                                    <input type="text" name="judul" class="form-control"
                                        value="<?php echo e($item->judul); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Kategori</label>
                                    <select name="kategori_id" class="form-control">
                                        <option value="">-- Pilih Kategori --</option>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($k->id); ?>"
                                                <?php echo e($item->kategori_id == $k->id ? 'selected' : ''); ?>>
                                                <?php echo e($k->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>Link Video</label>
                                    <input type="url" name="link_video" class="form-control"
                                        value="<?php echo e($item->link_video); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Ganti Gambar Cover (opsional)</label>
                                    <input type="file" name="gambar" class="form-control">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label>Isi Materi</label>
                                
                                <textarea name="isi" id="editorIsi<?php echo e($item->id); ?>"><?php echo e($item->isi); ?></textarea>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary">Update</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <!-- Summernote CSS & JS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js"></script>



    <script>
        $(function() {
            $('#datatable').DataTable();
        });
    </script>
    
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script>
        // Tambah Materi
        ClassicEditor
            .create(document.querySelector('#editorIsi'), {
                ckfinder: {
                    uploadUrl: "<?php echo e(route('materi.upload')); ?>?_token=<?php echo e(csrf_token()); ?>"
                }
            })
            .catch(error => {
                console.error(error);
            });

        // Edit Materi (looping semua modal edit)
        <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            ClassicEditor
                .create(document.querySelector('#editorIsi<?php echo e($item->id); ?>'), {
                    ckfinder: {
                        uploadUrl: "<?php echo e(route('materi.upload')); ?>?_token=<?php echo e(csrf_token()); ?>"
                    }
                })
                .catch(error => {
                    console.error(error);
                });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\media-pembelajaran\resources\views/admin/data-materi.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan Data Responder</title>
  <style>
    * { font-family: DejaVu Sans, Arial, sans-serif; }
    body { font-size: 12px; color: #222; }
    h2 { margin: 0 0 8px 0; }
    .meta { margin-bottom: 12px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #888; padding: 6px 8px; vertical-align: top; }
    thead th { background: #f0f0f0; }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .small { font-size: 11px; color: #666; }
  </style>
</head>
<body>
  <h2>Laporan Data Responder</h2>
  <div class="meta">
    <div class="small">Dibuat: <?php echo e($generated); ?></div>
    <?php if($q): ?>
      <div class="small">Filter: "<?php echo e($q); ?>"</div>
    <?php endif; ?>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width:40px;">No</th>
        <th>Nama</th>
        <th style="width:55px;">Usia</th>
        <th style="width:85px;">Gender</th>
        <th style="width:80px;">Skor</th>
        <th style="width:90px;">Jawaban</th>
        <th style="width:120px;">Tanggal</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $genderText = function($g) {
          return $g === 'male' ? 'Laki-laki' : ($g === 'female' ? 'Perempuan' : 'Lainnya');
        };
      ?>
      <?php $__empty_1 = true; $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-center"><?php echo e($i + 1); ?></td>
          <td><?php echo e($r->name); ?></td>
          <td class="text-center"><?php echo e($r->age); ?></td>
          <td><?php echo e($genderText($r->gender)); ?></td>
          <td class="text-center"><?php echo e($r->total_score ?? 0); ?></td>
          <td class="text-center"><?php echo e($r->answers_count ?? 0); ?></td>
          <td><?php echo e(optional($r->created_at)->format('d M Y, H:i')); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7" class="text-center small">Tidak ada data.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\si-pental\resources\views/admin/responder_pdf.blade.php ENDPATH**/ ?>
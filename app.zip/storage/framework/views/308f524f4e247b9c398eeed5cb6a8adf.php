


<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>
            <img src="/images/profil.png" alt="">
        </div>

        <div class="dash-content">
            <div class="activity">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="title">
                        <i class="bi bi-question-circle me-2"></i>
                        <span class="text fs-5">Data Soal</span>
                    </div>
                  
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                  <button class="btn btn-primary text-end" data-bs-toggle="modal" data-bs-target="#modalTambah">
                        <i class="bi bi-plus-circle me-1"></i> Tambah Soal
                    </button>
                <div class="table-responsive">
                    <table id="tabelFuzzifikasi" class="table table-bordered table-striped">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Materi</th>
                                <th>Pertanyaan</th>
                                <th>Pilihan A</th>
                                <th>Pilihan B</th>
                                <th>Pilihan C</th>
                                <th>Pilihan D</th>
                                <th>Pilihan E</th>
                                <th>Jawaban</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($item->materi->judul ?? '-'); ?></td>
                                    <td><?php echo e($item->pertanyaan); ?></td>
                                    <td><?php echo e($item->pilihan_a); ?></td>
                                    <td><?php echo e($item->pilihan_b); ?></td>
                                    <td><?php echo e($item->pilihan_c); ?></td>
                                    <td><?php echo e($item->pilihan_d); ?></td>
                                    <td><?php echo e($item->pilihan_e); ?></td>
                                    <td><?php echo e(strtoupper($item->jawaban_benar)); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#modalEdit<?php echo e($item->id); ?>">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <form action="<?php echo e(route('soal.destroy', $item->id)); ?>" method="POST"
                                            class="d-inline" onsubmit="return confirm('Yakin hapus soal ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash"></i> 
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="modal fade" id="modalTambah" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <form action="<?php echo e(route('soal.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Tambah Soal</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    
                                    <div class="mb-3">
                                        <label for="materi_id" class="form-label">Materi</label>
                                        <select name="materi_id" class="form-select" required>
                                            <option value="">-- Pilih Materi --</option>
                                            <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($m->id); ?>"><?php echo e($m->judul); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="pertanyaan" class="form-label">Pertanyaan</label>
                                        <textarea name="pertanyaan" class="form-control" rows="2" required></textarea>
                                    </div>

                                    <?php $__currentLoopData = ['a', 'b', 'c', 'd', 'e']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-3">
                                            <label for="pilihan_<?php echo e($opt); ?>" class="form-label">Pilihan
                                                <?php echo e(strtoupper($opt)); ?></label>
                                            <input type="text" name="pilihan_<?php echo e($opt); ?>" class="form-control"
                                                required>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="mb-3">
                                        <label for="jawaban_benar" class="form-label">Jawaban Benar</label>
                                        <select name="jawaban_benar" class="form-select" required>
                                            <?php $__currentLoopData = ['a', 'b', 'c', 'd', 'e']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($opt); ?>">Pilihan <?php echo e(strtoupper($opt)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary">Simpan</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                
                <div class="modal fade" id="modalEdit<?php echo e($item->id); ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <form action="<?php echo e(route('soal.update', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Soal</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    
                                    
                                    <div class="mb-3">
                                        <label for="materi_id" class="form-label">Materi</label>
                                        <select name="materi_id" class="form-select" required>
                                            <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($m->id); ?>"
                                                    <?php echo e($item->materi_id == $m->id ? 'selected' : ''); ?>>
                                                    <?php echo e($m->judul); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="pertanyaan" class="form-label">Pertanyaan</label>
                                        <textarea name="pertanyaan" class="form-control" rows="2" required><?php echo e($item->pertanyaan); ?></textarea>
                                    </div>

                                    <?php $__currentLoopData = ['a', 'b', 'c', 'd', 'e']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-3">
                                            <label for="pilihan_<?php echo e($opt); ?>" class="form-label">Pilihan
                                                <?php echo e(strtoupper($opt)); ?></label>
                                            <input type="text" name="pilihan_<?php echo e($opt); ?>"
                                                class="form-control" value="<?php echo e($item['pilihan_' . $opt]); ?>" required>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="mb-3">
                                        <label for="jawaban_benar" class="form-label">Jawaban Benar</label>
                                        <select name="jawaban_benar" class="form-select" required>
                                            <?php $__currentLoopData = ['a', 'b', 'c', 'd', 'e']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($opt); ?>"
                                                    <?php echo e($item->jawaban_benar == $opt ? 'selected' : ''); ?>>
                                                    Pilihan <?php echo e(strtoupper($opt)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>


                                    <div class="modal-footer">
                                        <button class="btn btn-primary">Simpan</button>
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Batal</button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>

     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#tabelFuzzifikasi').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "lengthMenu": [5, 10, 25, 50, 100],
                "language": {
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Tidak ada data yang ditemukan",
                    "info": "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
                    "infoEmpty": "Tidak ada data tersedia",
                    "search": "Cari:",
                    "paginate": {
                        "first": "Awal",
                        "last": "Akhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelumnya"
                    }
                },
                "columnDefs": [{
                    "orderable": false,
                    "targets": "_all"
                }]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\media-pembelajaran\resources\views/admin/data-soal.blade.php ENDPATH**/ ?>